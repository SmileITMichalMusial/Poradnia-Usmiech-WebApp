create definer = agnieszkadwa_poradniausmiech@`%` view priceList as
select `p1`.`id_layer_1`       AS `id_layer_1`,
       `p2`.`id_layer_2`       AS `id_layer_2`,
       `p1`.`order_id_layer_1` AS `order_id_layer_1`,
       `p2`.`order_id_layer_2` AS `order_id_layer_2`,
       `p1`.`description`      AS `L1_opis`,
       `p2`.`name`             AS `L2_nazwa`,
       `p2`.`duration`         AS `L2_czas_trwania`,
       `p2`.`price`            AS `cena`,
       `p1`.`dateCreated`      AS `L1_data_stworzenia`,
       `p2`.`dateCreated`      AS `L2_data_stworzenia`
from `agnieszkadwa_poradniausmiech`.`price_list_layer_1` `p1`
       join `agnieszkadwa_poradniausmiech`.`price_list_layer_2` `p2`
where (`p1`.`id_layer_1` = `p2`.`fk_id_layer_1`);

